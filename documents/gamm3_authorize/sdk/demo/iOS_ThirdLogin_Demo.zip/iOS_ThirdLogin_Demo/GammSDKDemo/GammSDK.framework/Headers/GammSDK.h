//
//  GammSDK.h
//  GammSDK
//
//  Created by robin on 2017/11/8.
//  Copyright © 2017年 ztgame.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <GammSDK/GammSDKApi.h>
#import <GammSDK/GammSDKApiObject.h>
